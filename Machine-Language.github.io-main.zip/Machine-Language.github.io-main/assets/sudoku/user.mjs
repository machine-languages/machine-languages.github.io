import { Sudoku } from "/sudoku.js"
const node = document.querySelector('[sudoku]')
// const sudoku = new Sudoku(node);


