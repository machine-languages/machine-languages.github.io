up.link.config.followSelectors.push('a[href]')
up.link.config.instantSelectors.push('a[href]')
up.link.config.preloadSelectors.push('a[href]')
up.fragment.config.mainTargets.push('.layout--main')
up.radio.config.hungrySelectors.push(
  'meta[property="og:title"]',
  'meta[property="og:type"]',
  'meta[property="og:image"]',
  'meta[property="og:url"]',
  'meta[property="og:description"]'
)

