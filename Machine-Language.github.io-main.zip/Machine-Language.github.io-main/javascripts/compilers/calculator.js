import { Calculator } from "../../assets/calculator/calculator.js"

up.compiler('[calculator]', function(element) {
  const calculator = new Calculator();
});
