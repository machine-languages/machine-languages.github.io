import { Sudoku } from "../../assets/sudoku/sudoku.js"

up.compiler('[sudoku]', function(element) {
  let sudoku = new Sudoku(element);
  return sudoku = 0;
});
