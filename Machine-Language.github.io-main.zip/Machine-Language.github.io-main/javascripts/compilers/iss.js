import { Iss } from "../../assets/iss/iss.js"

up.compiler('[iss]', function() {
  let iss = new Iss();
});
