
import { Chess } from "../../assets/chess/chess.js"

up.compiler('[chess]', function(element) {
  const chess = new Chess();
});
