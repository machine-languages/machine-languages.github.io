import { WhackAMole } from "../../assets/whack-mole/mole.js"

up.compiler('[mole]', function(element) {
  let mole = new WhackAMole();
  // return document.querySelector(".score-view").style = "display: none"
});
