import { PasswordGenerator } from "../../assets/password-generator/password-generator.js"

up.compiler('[password-generator]', function() {
  let passGenerator = new PasswordGenerator();
  return passGenerator = 0;
});
